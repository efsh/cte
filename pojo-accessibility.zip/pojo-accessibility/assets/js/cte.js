jQuery(document).ready(function ($) {

    $('.pojo-a11y-btn-vlibras').click(function () {
        $('.link-vlibras').toggleClass('visivel');
    });
    
});
